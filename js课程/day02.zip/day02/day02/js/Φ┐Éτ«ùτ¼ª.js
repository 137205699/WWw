//赋值运算符 =
//算术运算符 + - * / %
//复合运算符 += -= *= /= %=

//优先级  --->  ()

var num = 10;
//num = num + 10;
num += 10;  //num = num + 10;
//document.write(num + "<br />");

var num = 10;
//num += 1;
//num = num + 1;
//单目运算符
//++   自身+1
//--   自身-1
//前++  先+1再使用值
//后++  先取值 再+1
var num = 10;
var ret = ++num;
//document.write(ret + "," + num +  "<br />");

//boolean  ---> 真true 假false
//关系运算符  > < >= <= !=  ==(值相等)  ===(值相等并且类型相同)
//结果是一个boolean

document.write(1 < 2);

//if 分支语句  如果
/*
 * if(关系表达式){语句;}
 * 
 */

if(1 < 2){
	document.write("<br />hello js<br />");
}

/*
 * num = -num  求得绝对值  -1  1   1  1
 */

var ret = -10;
//var ret = prompt("请输入一个数字");
var num = parseInt(ret);

if(num < 0){
	num = -num;
}
document.write(num + "<br />");

//0 < num < 100
var num = 150; 

//0 < num 
//num < 100
if(0 < num && num < 100){
	document.write("hello <br />");
}

//逻辑运算符  1 and (&&) 2   or(||)   取反!  0  1  1 0
// 1 && 2  
// 1 || 2

//输入一个年份 判断不是闰年
//四年一闰且百年不闰  或者 400再闰
//var year = parseInt(prompt("输一个年份"));
if(!((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)){
 	document.write(year + "不是闰年 <br />");
}




