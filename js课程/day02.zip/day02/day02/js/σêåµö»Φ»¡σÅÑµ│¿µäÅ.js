
if(1>2);
//空的if语句
{
	document.write("hello");
	document.write("123");
}
//if(关系表达式){}   //非0即为真 false
if(2){
	document.write("hello");
}
//
var num = 2;
if(2 == num){
	document.write("hello");
}
//sw
//把结果出现概率比较高的标签写到前面

	
