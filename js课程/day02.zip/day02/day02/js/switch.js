//switch 开关
/*
 	switch(表达式){
 		//标签1 常量
 		case 标签1:
 			break;跳出switch
 		case 标签2:
 			break;
 		case 标签3:
 			break;
 		case 标签4:
 			break;
 		...
 		default:
 	}
 * */

var num = "A";
//0 1 10 no data
switch(num){
	case "A":
		document.write("0 <br />");
		break;
	case 1: //1 
		document.write("1 <br />");
		break;
	case 10:
		document.write("10 <br />");
		break;
	default:
		document.write("no data <br />");
}
//1. 给出一个月份  输出月份对应的天数  2 28/29

//1 3 5 7 8 10 12

var month = 5;

switch(month){
	case 1:
	case 3:
	case 5:
	case 7:
	case 8:
	case 10:
	case 12:
		document.write("31 <br />");
		break;
	case 2:
		document.write("28/29 <br />");
		break;
	case 4:
	case 6:
	case 9:
	case 11:
		document.write("30 <br />");
		break;
	default:
		document.write("input error <br />");
}

//2.
//60 - 69 "D"  60 61 ... 69  D
//70 - 79 "C"
//80 - 89 "B"
//90 - 100 "A" 
//6 7 8 9 10

var score = 100;

switch(parseInt(score / 10)){
	case 6:
		document.write("D <br />");
		break;
	case 7:
		document.write("C <br />");
		break;
	case 8:
		document.write("B <br />");
		break;
	case 9:
	case 10:
		document.write("A <br />");
		break;
}


