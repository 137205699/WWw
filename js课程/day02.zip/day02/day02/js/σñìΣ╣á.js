
//常量
//整形  浮点型  字符串  boolean true false

//整形 ---> 2进制  8
//字符串 "z"   ---->  ascii码    a  97  A 65 0 47

//变量  
//var 变量名;   undefined  NAN   1 / 0
// 1 a _ $
// a _ $ 
// var 
// 

// = 

var num = 345;

document.write(num % 10 + "<br />");
document.write(parseInt(num / 10) % 10 + "<br />");
document.write(parseInt(num / 100) % 10 + "<br />");