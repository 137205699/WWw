//2进制  0 1
//位  &   |   
//^   相同为0不同为1

document.write(5 & 3);
document.write("<br />");
document.write(5 | 3);
document.write("<br />");
document.write(5 ^ 3);
document.write("<br />");

//^  交换两个数的值

//中间变量  浪费内存
//加减法(100)   num = 89  + num = 88     溢出

//1 + -1   溢出
//var num1 = 234567654356786756756;
//var num2 = 234567435354353453453;
//
//var num = num1 + num2;
//document.write(num);
//^
var a = 6;
var b = 4;
//110
//100
//010
a = a ^ b; //a = 2  b = 4
b = a ^ b; //b = 6  a = 2
a = a ^ b; //a = 4  b = 6
document.write(a + "," + b + "<br />");

//101
//011
//001
//
//101 
//011
//111
//
//^
//101 
//011
//110

