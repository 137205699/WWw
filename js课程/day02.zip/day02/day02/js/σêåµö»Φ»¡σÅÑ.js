//语句;
//顺序化
//分支语句 if  switch
//if(语句){语句}
//循环语句

//
var num = 80;
if(num < 60){
	document.write("不及格<br />");
}

if(num >= 60){
	document.write("及格<br />");
}

//保存两个数的最大值  输出最大值
var a = 10;
var b = 20;
var max = 0;

if(a < b){
	max = b;
}

if(b <= a){
	max = a;
}

document.write(max + "<br />");

//if可以嵌套
/*
 * if(){
	if(){
		
	}
}
*/

//评分 > 60
//A B 
//C 70 - 79
//D 60 - 69   D+ 65 - 69  D- 60 - 65

var score = 68;
if(score >= 60){
	if(score < 65){
		document.write("D-");
	}
	
	if(score >= 65 && score <= 69){
		document.write("D+");
	}
}

/*
 	if(条件){
 		语句1;
 	}else{
 		语句2;
 	}
 * */

var a = 10;
var b = 20;
var max = 0;
if(a < b){
	max = b;
}else{  // b <= a
	max = a;
}
document.write("<br />" + max);
//if...else
//三目运算符 最大和最小
/*
 * 关系表达式 ? 语句1 : 语句2;
 * 
 */
var a = 10;
var b = 20;
var max = 0;
max = a < b ? b : a;
document.write("<br />" + max);

//多种情况
/*
	x ^ 2 + 1 (x < 0)
y = 	5 * x + 100 (0 <= x < 100)
	20 * x - 1000 (100 <= x < 500)
*/

/*
 	if(条件){
 		
 	}else if(条件){
 		
 	}else if(条件){
 		
 	}else{
 		
 	}
 * */

var y = 0;
var x = 10;

if(x < 0){
	y = x * x + 1;
}else if(x >= 0 && x < 100){
	y = 5 * x + 100;
}else if(x >= 100 && x < 500){
	y = 20 * x - 1000;
}
document.write("<br />" + y + "<br />");

//60 - 69 "D"
//70 - 79 "C"
//80 - 89 "B"
//90 - 100 "A"

var score = parseInt(prompt("请输入一个分数"));

if(score >= 60 && score <= 69){
	document.write("D <br />");
}else if(score >= 70 && score <= 79){
	document.write("C <br />");
}else if(score >= 80 && score <= 89){
	document.write("B <br />");
}else if(score >= 90 && score <= 100){
	document.write("A <br />");
}










